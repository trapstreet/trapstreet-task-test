# @trapstreet/sdk

Author types, runtime schemas, static Task Project validation and file-reading helpers for Trapstreet.

Development version **0.2.0**, protocol **2026.09.2**, TypeScript + ESM on Node.js 24. This package has not been published. The `private` flag and `UNLICENSED` marker remain until the owner selects a license and authorizes a release.

```ts
import {defineJudge, defineReporter} from '@trapstreet/sdk';

export const judge = defineJudge(async () => ({type: 'score', value: 100}));
export const reporter = defineReporter(async ({summary}) => {
  if (summary.averageScore === null) throw new Error('No valid scores');
  return {type: 'score', value: summary.averageScore};
});
```

In a Task Project use default exports in `cases/<directory>/judge.ts` and `reporter.ts`. Declare each evaluator's `requires` in YAML. The helpers provide author typing; the platform Runner owns input/output validation, calling functions, timeout/error records and isolation. They do not catch exceptions, execute retries or convert errors into business results.

Exports:

- `@trapstreet/sdk`: configuration/result/context schemas, inferred types, `defineJudge`, `defineReporter`, `aggregateCases`, result parsers, JSON validation, version constants, `readUsageMetric` and `requireCompleteUsageMetric`.
- `@trapstreet/sdk/project`: `validateProject`, `validatePackageFiles`, `parseTaskYaml`, `parseCaseYaml`, `ProjectValidationError`.
- `@trapstreet/sdk/files`: `readText(directory, relativePath)`, `readJson(directory, relativePath)`, `listFiles(directory)`.

See [the toolkit repository](https://github.com/trapstreet/trapstreet-sdk) for protocol documentation and hand-authored score/result/null examples. No platform source, model client, CLI, sandbox runner or deployment credentials are included.

## Reading Usage

```ts
import {readUsageMetric, requireCompleteUsageMetric} from '@trapstreet/sdk';
// Inside a Judge/Reporter whose YAML requires usage:
const cost = readUsageMetric(context.usage, 'cost_usd');
if (cost.status === 'complete') {
  // cost.value is an exact decimal string for the entire scope, including true zero.
} else if (cost.status === 'partial') {
  // cost.observed is explicitly partial; cost.reasons explains the gap.
} else {
  // unknown, unavailable or not_requested: no cost value; do not substitute zero.
}
// An author who requires a total can opt into a failure on incomplete evidence:
const completeCost = requireCompleteUsageMetric(context.usage, 'cost_usd');
```

Available snapshots separate complete `metrics` from partial `observed` values and carry request coverage, per-metric completeness and gap reasons. Tokens/market cost can be unknown while cost is complete. SDK 0.2.0 / protocol 2026.09.2 replaces the Reporting context; old SDKs are not supported. USD remains an exact decimal string; partial Usage is never permission to charge partial costs.
